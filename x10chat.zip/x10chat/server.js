/**
 * X10 Chat — Server
 * Encrypted internal chat for your network
 * Features: REST auth, WebSocket messaging, WebRTC signaling, file upload
 */

const express  = require('express');
const http     = require('http');
const WebSocket = require('ws');
const multer   = require('multer');
const bcrypt   = require('bcryptjs');
const { v4: uuid } = require('uuid');
const crypto   = require('crypto');
const fs       = require('fs');
const path     = require('path');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server, path: '/ws' });
const PORT   = process.env.PORT || 3000;

// ── Directories ───────────────────────────────────────────────────
const DATA_DIR    = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const DATA_FILE   = path.join(DATA_DIR, 'store.json');
[DATA_DIR, UPLOADS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── Persistent store ──────────────────────────────────────────────
let store = { users: {}, invites: {}, sessions: {}, files: {} };
function loadStore() {
  if (fs.existsSync(DATA_FILE)) {
    try { store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
    catch(e) { console.error('Store load error:', e.message); }
  }
}
function saveStore() {
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2)); }
  catch(e) { console.error('Store save error:', e.message); }
}
loadStore();

// ── Multer file storage ───────────────────────────────────────────
const storage = multer.diskStorage({
  destination: UPLOADS_DIR,
  filename: (req, file, cb) => cb(null, uuid() + path.extname(file.originalname))
});
const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200 MB
  fileFilter: (req, file, cb) => {
    // Block executable types
    const blocked = ['.exe', '.bat', '.cmd', '.sh', '.ps1', '.com'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (blocked.includes(ext)) return cb(new Error('File type not allowed'));
    cb(null, true);
  }
});

// ── Middleware ────────────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Auth middleware
function auth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token' });
  const session = store.sessions[token];
  if (!session) return res.status(401).json({ error: 'Invalid token' });
  // 30-day session expiry
  if (Date.now() - session.createdAt > 30 * 24 * 60 * 60 * 1000) {
    delete store.sessions[token];
    return res.status(401).json({ error: 'Session expired' });
  }
  req.user = store.users[session.username];
  if (!req.user) return res.status(401).json({ error: 'User not found' });
  next();
}

// ── REST Endpoints ────────────────────────────────────────────────

// Check if setup needed
app.get('/api/status', (req, res) => {
  res.json({ needsSetup: Object.keys(store.users).length === 0 });
});

// First-time admin setup
app.post('/api/setup', async (req, res) => {
  if (Object.keys(store.users).length > 0) return res.status(403).json({ error: 'Already configured' });
  const { username, password, publicKey } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  if (username.length < 2 || username.length > 32) return res.status(400).json({ error: 'Username must be 2-32 chars' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 chars' });
  const id = uuid();
  const passwordHash = await bcrypt.hash(password, 12);
  store.users[username] = {
    id, username, passwordHash, publicKey: publicKey || '',
    role: 'admin', avatar: '', createdAt: Date.now()
  };
  saveStore();
  res.json({ ok: true });
});

// Login
app.post('/api/login', async (req, res) => {
  const { username, password, publicKey } = req.body;
  const user = store.users[username];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  if (publicKey && publicKey !== user.publicKey) {
    user.publicKey = publicKey;
    saveStore();
  }
  const token = crypto.randomBytes(40).toString('hex');
  store.sessions[token] = { username, createdAt: Date.now() };
  // Prune old sessions (keep max 5 per user)
  const userSessions = Object.entries(store.sessions).filter(([,s]) => s.username === username);
  if (userSessions.length > 5) {
    userSessions.sort(([,a],[,b]) => a.createdAt - b.createdAt)
      .slice(0, userSessions.length - 5)
      .forEach(([k]) => delete store.sessions[k]);
  }
  saveStore();
  res.json({
    token,
    user: { id: user.id, username: user.username, role: user.role, publicKey: user.publicKey },
    users: Object.values(store.users).map(u => ({
      id: u.id, username: u.username, publicKey: u.publicKey, role: u.role
    }))
  });
});

// Logout
app.post('/api/logout', auth, (req, res) => {
  const token = req.headers['authorization'].slice(7);
  delete store.sessions[token];
  saveStore();
  res.json({ ok: true });
});

// Create invite link (any logged-in user can invite)
app.post('/api/invite', auth, (req, res) => {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000; // 7 days
  store.invites[token] = {
    createdBy: req.user.username,
    createdAt: Date.now(),
    expiresAt,
    used: false
  };
  saveStore();
  res.json({ token, expiresAt });
});

// Validate invite
app.get('/api/invite/:token', (req, res) => {
  const invite = store.invites[req.params.token];
  if (!invite) return res.status(404).json({ error: 'Invalid invite' });
  if (invite.used) return res.status(410).json({ error: 'Invite already used' });
  if (invite.expiresAt < Date.now()) return res.status(410).json({ error: 'Invite expired' });
  res.json({ createdBy: invite.createdBy, expiresAt: invite.expiresAt });
});

// Register via invite
app.post('/api/register', async (req, res) => {
  const { token, username, password, publicKey } = req.body;
  if (!token || !username || !password) return res.status(400).json({ error: 'Missing fields' });
  const invite = store.invites[token];
  if (!invite) return res.status(400).json({ error: 'Invalid invite' });
  if (invite.used) return res.status(400).json({ error: 'Invite already used' });
  if (invite.expiresAt < Date.now()) return res.status(400).json({ error: 'Invite expired' });
  if (store.users[username]) return res.status(409).json({ error: 'Username already taken' });
  if (username.length < 2 || username.length > 32) return res.status(400).json({ error: 'Username must be 2-32 chars' });
  if (password.length < 6) return res.status(400).json({ error: 'Password too short (min 6)' });
  const passwordHash = await bcrypt.hash(password, 12);
  store.users[username] = {
    id: uuid(), username, passwordHash, publicKey: publicKey || '',
    role: 'user', avatar: '', createdAt: Date.now()
  };
  store.invites[token].used = true;
  store.invites[token].usedBy = username;
  saveStore();
  // Notify online users
  broadcast({ type: 'user-joined', user: { id: store.users[username].id, username, publicKey: publicKey || '' } });
  res.json({ ok: true });
});

// Get all users with public keys (for encryption)
app.get('/api/users', auth, (req, res) => {
  res.json(Object.values(store.users).map(u => ({
    id: u.id, username: u.username, publicKey: u.publicKey, role: u.role,
    online: clients.has(u.username)
  })));
});

// Upload file
app.post('/api/upload', auth, (req, res, next) => {
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file provided' });
    const fileId = uuid();
    store.files[fileId] = {
      id: fileId,
      name: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
      filename: req.file.filename,
      uploadedBy: req.user.username,
      uploadedAt: Date.now()
    };
    saveStore();
    res.json({ fileId, name: req.file.originalname, size: req.file.size, mimetype: req.file.mimetype });
  });
});

// Download file
app.get('/api/file/:fileId', auth, (req, res) => {
  const meta = store.files[req.params.fileId];
  if (!meta) return res.status(404).json({ error: 'File not found' });
  const filePath = path.join(UPLOADS_DIR, meta.filename);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File missing from disk' });
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(meta.name)}"`);
  res.setHeader('Content-Type', meta.mimetype);
  res.sendFile(filePath);
});

// Change password
app.post('/api/change-password', auth, async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Missing fields' });
  if (newPassword.length < 6) return res.status(400).json({ error: 'Password too short' });
  const ok = await bcrypt.compare(oldPassword, req.user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Current password is wrong' });
  req.user.passwordHash = await bcrypt.hash(newPassword, 12);
  saveStore();
  res.json({ ok: true });
});

// ── WebSocket ─────────────────────────────────────────────────────
const clients = new Map(); // username → ws

function broadcast(msg, excludeUser = null) {
  const data = JSON.stringify(msg);
  clients.forEach((ws, username) => {
    if (username !== excludeUser && ws.readyState === WebSocket.OPEN) ws.send(data);
  });
}

function sendTo(username, msg) {
  const ws = clients.get(username);
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(msg));
    return true;
  }
  return false;
}

wss.on('connection', (ws) => {
  let username = null;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    // ── Auth handshake ─────────────────────────────────────────
    if (msg.type === 'auth') {
      const session = store.sessions[msg.token];
      if (!session || !store.users[session.username]) {
        ws.send(JSON.stringify({ type: 'auth-error', reason: 'Invalid token' }));
        return;
      }
      username = session.username;
      // Close any existing connection for this user
      const existing = clients.get(username);
      if (existing && existing !== ws && existing.readyState === WebSocket.OPEN) {
        existing.send(JSON.stringify({ type: 'session-replaced' }));
        existing.close();
      }
      clients.set(username, ws);
      broadcast({ type: 'user-online', username }, username);
      ws.send(JSON.stringify({
        type: 'auth-ok',
        onlineUsers: [...clients.keys()].filter(u => u !== username)
      }));
      return;
    }

    if (!username) return;

    switch (msg.type) {

      // ── Encrypted chat message ─────────────────────────────
      case 'message': {
        const delivered = sendTo(msg.to, {
          type: 'message',
          id: msg.id,
          from: username,
          to: msg.to,
          payload: msg.payload,     // encrypted blob
          fileId: msg.fileId || null,
          fileName: msg.fileName || null,
          fileSize: msg.fileSize || null,
          fileMime: msg.fileMime || null,
          ts: Date.now()
        });
        ws.send(JSON.stringify({ type: 'message-ack', id: msg.id, delivered, ts: Date.now() }));
        break;
      }

      // ── Typing indicators ──────────────────────────────────
      case 'typing':
        sendTo(msg.to, { type: 'typing', from: username });
        break;
      case 'stop-typing':
        sendTo(msg.to, { type: 'stop-typing', from: username });
        break;

      // ── Read receipts ──────────────────────────────────────
      case 'read':
        sendTo(msg.from, { type: 'read', by: username, ids: msg.ids });
        break;

      // ── WebRTC signaling ───────────────────────────────────
      case 'call-offer':
      case 'call-answer':
      case 'ice-candidate':
      case 'call-end':
      case 'call-reject':
      case 'call-busy':
        if (msg.to) sendTo(msg.to, { ...msg, from: username });
        break;

      default:
        break;
    }
  });

  ws.on('close', () => {
    if (username && clients.get(username) === ws) {
      clients.delete(username);
      broadcast({ type: 'user-offline', username });
    }
  });

  ws.on('error', (err) => {
    console.error(`WS error [${username || 'unauth'}]:`, err.message);
  });
});

// ── Start ─────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  const ifaces = require('os').networkInterfaces();
  const ips = Object.values(ifaces).flat()
    .filter(i => i.family === 'IPv4' && !i.internal)
    .map(i => i.address);

  console.log('\n╔════════════════════════════════════════╗');
  console.log('║         X10 Chat Server — Ready        ║');
  console.log('╠════════════════════════════════════════╣');
  ips.forEach(ip => console.log(`║  🌐  http://${ip}:${PORT}`.padEnd(42) + '║'));
  console.log(`║  🏠  http://localhost:${PORT}`.padEnd(43) + '║');
  console.log('╠════════════════════════════════════════╣');
  console.log('║  First run: /setup to create admin     ║');
  console.log('╚════════════════════════════════════════╝\n');
});
