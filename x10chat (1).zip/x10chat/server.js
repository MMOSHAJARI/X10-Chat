/**
 * X10 Chat — Server v2
 * New: Admin API, CORS for standalone client, audit log, /api/ping
 */
const express   = require('express');
const http      = require('http');
const WebSocket = require('ws');
const multer    = require('multer');
const bcrypt    = require('bcryptjs');
const { v4: uuid } = require('uuid');
const crypto    = require('crypto');
const fs        = require('fs');
const path      = require('path');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server, path: '/ws' });
const PORT   = process.env.PORT || 3000;

// ── Data directories ──────────────────────────────────────────────
const DATA_DIR    = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const DATA_FILE   = path.join(DATA_DIR, 'store.json');
[DATA_DIR, UPLOADS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── Store ─────────────────────────────────────────────────────────
let store = { users: {}, invites: {}, sessions: {}, files: {}, auditLog: [] };
function loadStore() {
  if (fs.existsSync(DATA_FILE)) {
    try { store = { ...store, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) }; if (!store.auditLog) store.auditLog = []; }
    catch(e) { console.error('Store load error:', e.message); }
  }
}
function saveStore() {
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2)); }
  catch(e) { console.error('Store save error:', e.message); }
}
loadStore();

function audit(actor, action, target = '', detail = '') {
  store.auditLog.unshift({ ts: Date.now(), actor, action, target, detail });
  if (store.auditLog.length > 200) store.auditLog.length = 200;
}

// ── Multer ────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: UPLOADS_DIR,
  filename: (req, file, cb) => cb(null, uuid() + path.extname(file.originalname))
});
const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (['.exe','.bat','.cmd','.sh','.ps1','.com'].includes(path.extname(file.originalname).toLowerCase()))
      return cb(new Error('File type not allowed'));
    cb(null, true);
  }
});

// ── Middleware ────────────────────────────────────────────────────
// Full CORS — required for standalone HTML client over HTTP LAN
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Auth
function auth(req, res, next) {
  const hdr = req.headers['authorization'] || '';
  const tok = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!tok) return res.status(401).json({ error: 'No token' });
  const sess = store.sessions[tok];
  if (!sess) return res.status(401).json({ error: 'Invalid token' });
  if (Date.now() - sess.createdAt > 30*24*60*60*1000) { delete store.sessions[tok]; return res.status(401).json({ error: 'Session expired' }); }
  req.user = store.users[sess.username];
  if (!req.user) return res.status(401).json({ error: 'User not found' });
  next();
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ═════════════════════════════════════════════════════════════════
//  Core Routes
// ═════════════════════════════════════════════════════════════════

app.get('/api/ping', (req, res) =>
  res.json({ ok: true, name: 'X10 Chat', version: '2.0', ts: Date.now() }));

app.get('/api/status', (req, res) =>
  res.json({ needsSetup: Object.keys(store.users).length === 0 }));

app.post('/api/setup', async (req, res) => {
  if (Object.keys(store.users).length > 0) return res.status(403).json({ error: 'Already configured' });
  const { username, password, publicKey } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  if (username.length < 2 || username.length > 32) return res.status(400).json({ error: 'Username 2-32 chars' });
  if (password.length < 6) return res.status(400).json({ error: 'Password min 6 chars' });
  store.users[username] = {
    id: uuid(), username, passwordHash: await bcrypt.hash(password, 12),
    publicKey: publicKey || '', role: 'admin', createdAt: Date.now(), disabled: false
  };
  audit('system', 'setup', username);
  saveStore();
  res.json({ ok: true });
});

app.post('/api/login', async (req, res) => {
  const { username, password, publicKey } = req.body;
  const user = store.users[username];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  if (user.disabled) return res.status(403).json({ error: 'Account disabled — contact your admin' });
  if (!await bcrypt.compare(password, user.passwordHash)) {
    audit(username, 'login-fail', username);
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  if (publicKey && publicKey !== user.publicKey) user.publicKey = publicKey;
  user.lastLogin = Date.now();
  const token = crypto.randomBytes(40).toString('hex');
  store.sessions[token] = { username, createdAt: Date.now() };
  const userSessions = Object.entries(store.sessions).filter(([,s]) => s.username === username);
  if (userSessions.length > 5) {
    userSessions.sort(([,a],[,b]) => a.createdAt - b.createdAt)
      .slice(0, userSessions.length - 5).forEach(([k]) => delete store.sessions[k]);
  }
  audit(username, 'login');
  saveStore();
  res.json({
    token,
    user: { id: user.id, username: user.username, role: user.role, publicKey: user.publicKey },
    users: Object.values(store.users).map(u => ({
      id: u.id, username: u.username, publicKey: u.publicKey, role: u.role,
      online: clients.has(u.username), disabled: !!u.disabled
    }))
  });
});

app.post('/api/logout', auth, (req, res) => {
  delete store.sessions[req.headers['authorization'].slice(7)];
  audit(req.user.username, 'logout');
  saveStore();
  res.json({ ok: true });
});

app.post('/api/invite', auth, (req, res) => {
  const token = crypto.randomBytes(32).toString('hex');
  store.invites[token] = { createdBy: req.user.username, createdAt: Date.now(), expiresAt: Date.now()+7*24*60*60*1000, used: false };
  audit(req.user.username, 'invite-create');
  saveStore();
  res.json({ token, expiresAt: store.invites[token].expiresAt });
});

app.get('/api/invite/:token', (req, res) => {
  const inv = store.invites[req.params.token];
  if (!inv || inv.used || inv.expiresAt < Date.now()) return res.status(410).json({ error: 'Invalid or expired invite' });
  res.json({ createdBy: inv.createdBy, expiresAt: inv.expiresAt });
});

app.post('/api/register', async (req, res) => {
  const { token, username, password, publicKey } = req.body;
  if (!token || !username || !password) return res.status(400).json({ error: 'Missing fields' });
  const inv = store.invites[token];
  if (!inv || inv.used || inv.expiresAt < Date.now()) return res.status(400).json({ error: 'Invalid or expired invite' });
  if (store.users[username]) return res.status(409).json({ error: 'Username already taken' });
  if (username.length < 2 || username.length > 32) return res.status(400).json({ error: 'Username 2-32 chars' });
  if (password.length < 6) return res.status(400).json({ error: 'Password min 6 chars' });
  store.users[username] = {
    id: uuid(), username, passwordHash: await bcrypt.hash(password, 12),
    publicKey: publicKey || '', role: 'user', createdAt: Date.now(), disabled: false
  };
  inv.used = true; inv.usedBy = username;
  audit(username, 'register', username, `Invited by ${inv.createdBy}`);
  saveStore();
  broadcast({ type: 'user-joined', user: { id: store.users[username].id, username, publicKey: publicKey||'', role:'user' } });
  res.json({ ok: true });
});

app.get('/api/users', auth, (req, res) =>
  res.json(Object.values(store.users).map(u => ({
    id: u.id, username: u.username, publicKey: u.publicKey, role: u.role,
    online: clients.has(u.username), disabled: !!u.disabled, lastLogin: u.lastLogin, createdAt: u.createdAt
  }))));

app.post('/api/upload', auth, (req, res) => {
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file' });
    const fid = uuid();
    store.files[fid] = { id: fid, name: req.file.originalname, size: req.file.size, mimetype: req.file.mimetype, filename: req.file.filename, uploadedBy: req.user.username, uploadedAt: Date.now() };
    saveStore();
    res.json({ fileId: fid, name: req.file.originalname, size: req.file.size, mimetype: req.file.mimetype });
  });
});

app.get('/api/file/:fileId', auth, (req, res) => {
  const meta = store.files[req.params.fileId];
  if (!meta) return res.status(404).json({ error: 'File not found' });
  const fp = path.join(UPLOADS_DIR, meta.filename);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'File missing' });
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(meta.name)}"`);
  res.setHeader('Content-Type', meta.mimetype);
  res.sendFile(fp);
});

app.post('/api/change-password', auth, async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Missing fields' });
  if (newPassword.length < 6) return res.status(400).json({ error: 'Password too short' });
  if (!await bcrypt.compare(oldPassword, req.user.passwordHash)) return res.status(401).json({ error: 'Current password wrong' });
  req.user.passwordHash = await bcrypt.hash(newPassword, 12);
  audit(req.user.username, 'change-password');
  saveStore();
  res.json({ ok: true });
});

// ═════════════════════════════════════════════════════════════════
//  ADMIN API
// ═════════════════════════════════════════════════════════════════

// All users (detailed)
app.get('/api/admin/users', auth, adminOnly, (req, res) =>
  res.json(Object.values(store.users).map(u => ({
    id: u.id, username: u.username, role: u.role, disabled: !!u.disabled,
    online: clients.has(u.username), lastLogin: u.lastLogin||null, createdAt: u.createdAt,
    sessionCount: Object.values(store.sessions).filter(s => s.username === u.username).length
  }))));

// Update role / disabled
app.put('/api/admin/users/:username', auth, adminOnly, (req, res) => {
  const t = store.users[req.params.username];
  if (!t) return res.status(404).json({ error: 'User not found' });
  if (t.username === req.user.username) return res.status(400).json({ error: 'Cannot modify yourself here' });
  const { role, disabled } = req.body;
  if (role !== undefined) {
    if (!['admin','user'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
    t.role = role;
    audit(req.user.username, 'set-role', t.username, role);
    // Tell the affected user their role changed
    sendTo(t.username, { type: 'role-changed', role });
  }
  if (disabled !== undefined) {
    t.disabled = !!disabled;
    audit(req.user.username, disabled ? 'disable-user' : 'enable-user', t.username);
    if (disabled) {
      Object.entries(store.sessions).forEach(([tok, s]) => {
        if (s.username === t.username) { sendTo(t.username, { type: 'account-disabled' }); delete store.sessions[tok]; }
      });
    }
    broadcast({ type: disabled ? 'user-offline' : 'user-online', username: t.username });
  }
  saveStore();
  res.json({ ok: true, user: { username: t.username, role: t.role, disabled: t.disabled } });
});

// Force-reset password
app.post('/api/admin/users/:username/reset-password', auth, adminOnly, async (req, res) => {
  const t = store.users[req.params.username];
  if (!t) return res.status(404).json({ error: 'User not found' });
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Password min 6 chars' });
  t.passwordHash = await bcrypt.hash(newPassword, 12);
  Object.entries(store.sessions).forEach(([tok, s]) => {
    if (s.username === t.username) { sendTo(t.username, { type: 'session-replaced' }); delete store.sessions[tok]; }
  });
  audit(req.user.username, 'reset-password', t.username);
  saveStore();
  res.json({ ok: true });
});

// Delete user
app.delete('/api/admin/users/:username', auth, adminOnly, (req, res) => {
  const t = store.users[req.params.username];
  if (!t) return res.status(404).json({ error: 'User not found' });
  if (t.username === req.user.username) return res.status(400).json({ error: 'Cannot delete yourself' });
  Object.entries(store.sessions).forEach(([tok, s]) => {
    if (s.username === t.username) { sendTo(t.username, { type: 'account-deleted' }); delete store.sessions[tok]; }
  });
  delete store.users[t.username];
  audit(req.user.username, 'delete-user', t.username);
  broadcast({ type: 'user-removed', username: t.username });
  saveStore();
  res.json({ ok: true });
});

// Force logout (kick sessions)
app.post('/api/admin/users/:username/kick', auth, adminOnly, (req, res) => {
  const t = store.users[req.params.username];
  if (!t) return res.status(404).json({ error: 'User not found' });
  Object.entries(store.sessions).forEach(([tok, s]) => {
    if (s.username === t.username) { sendTo(t.username, { type: 'session-replaced' }); delete store.sessions[tok]; }
  });
  audit(req.user.username, 'kick-user', t.username);
  saveStore();
  res.json({ ok: true });
});

// Audit log
app.get('/api/admin/audit', auth, adminOnly, (req, res) =>
  res.json(store.auditLog.slice(0, 100)));

// Stats
app.get('/api/admin/stats', auth, adminOnly, (req, res) =>
  res.json({
    totalUsers: Object.keys(store.users).length,
    activeUsers: clients.size,
    totalSessions: Object.keys(store.sessions).length,
    totalFiles: Object.keys(store.files).length,
    totalInvites: Object.keys(store.invites).length,
    usedInvites: Object.values(store.invites).filter(i => i.used).length,
    uptime: Math.floor(process.uptime()),
    nodeVersion: process.version
  }));

// ═════════════════════════════════════════════════════════════════
//  WebSocket
// ═════════════════════════════════════════════════════════════════
const clients = new Map();

function broadcast(msg, excludeUser = null) {
  const data = JSON.stringify(msg);
  clients.forEach((ws, u) => { if (u !== excludeUser && ws.readyState === WebSocket.OPEN) ws.send(data); });
}
function sendTo(username, msg) {
  const ws = clients.get(username);
  if (ws && ws.readyState === WebSocket.OPEN) { ws.send(JSON.stringify(msg)); return true; }
  return false;
}

wss.on('connection', ws => {
  let username = null;

  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }

    if (msg.type === 'auth') {
      const sess = store.sessions[msg.token];
      if (!sess || !store.users[sess.username]) { ws.send(JSON.stringify({ type: 'auth-error' })); return; }
      const user = store.users[sess.username];
      if (user.disabled) { ws.send(JSON.stringify({ type: 'account-disabled' })); ws.close(); return; }
      username = sess.username;
      const existing = clients.get(username);
      if (existing && existing !== ws && existing.readyState === WebSocket.OPEN) {
        existing.send(JSON.stringify({ type: 'session-replaced' })); existing.close();
      }
      clients.set(username, ws);
      broadcast({ type: 'user-online', username }, username);
      ws.send(JSON.stringify({ type: 'auth-ok', onlineUsers: [...clients.keys()].filter(u => u !== username) }));
      return;
    }

    if (!username) return;
    switch (msg.type) {
      case 'message': {
        const delivered = sendTo(msg.to, { type:'message', id:msg.id, from:username, to:msg.to, payload:msg.payload, fileId:msg.fileId||null, fileName:msg.fileName||null, fileSize:msg.fileSize||null, fileMime:msg.fileMime||null, ts:Date.now() });
        ws.send(JSON.stringify({ type:'message-ack', id:msg.id, delivered, ts:Date.now() }));
        break;
      }
      case 'typing':      sendTo(msg.to,   { type:'typing',      from:username }); break;
      case 'stop-typing': sendTo(msg.to,   { type:'stop-typing', from:username }); break;
      case 'read':        sendTo(msg.from, { type:'read', by:username, ids:msg.ids }); break;
      case 'call-offer': case 'call-answer': case 'ice-candidate':
      case 'call-end': case 'call-reject': case 'call-busy':
        if (msg.to) sendTo(msg.to, { ...msg, from: username }); break;
    }
  });

  ws.on('close', () => {
    if (username && clients.get(username) === ws) {
      clients.delete(username);
      broadcast({ type: 'user-offline', username });
    }
  });
  ws.on('error', e => console.error(`WS[${username||'?'}]:`, e.message));
});

// ── Start ─────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  const ips = Object.values(require('os').networkInterfaces()).flat()
    .filter(i => i.family === 'IPv4' && !i.internal).map(i => i.address);
  console.log('\n╔══════════════════════════════════════════════╗');
  console.log('║       X10 Chat Server v2 — Ready            ║');
  console.log('╠══════════════════════════════════════════════╣');
  ips.forEach(ip => console.log(`║  🌐  http://${ip}:${PORT}`.padEnd(47)+'║'));
  console.log(`║  🏠  http://localhost:${PORT}`.padEnd(48)+'║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  Admin panel: /api/admin/users               ║');
  console.log('║  Standalone client: open index.html directly ║');
  console.log('╚══════════════════════════════════════════════╝\n');
});
